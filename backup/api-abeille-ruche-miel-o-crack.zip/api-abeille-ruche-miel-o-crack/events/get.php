<?php

include("../db.php");

$result = [];
$result['events'] = connectToDB()->query("SELECT * FROM Events ORDER BY id;")->fetch_all(MYSQLI_ASSOC);
foreach ($result['events'] as &$event) {
    $event['id'] = intval($event['id']);
    $event['start'] = floatval($event['start']);
    $event['end'] = floatval($event['end']);
    $event['imageUrl'] = 'https://'.$_SERVER['SERVER_NAME'].'/assets-spade-club-heart-diamond/events/'.$event['id'].'.jpg';
}

echo json_encode($result);

?>