<?php

include("../db.php");

$result = [];
$result['partnerships'] = connectToDB()->query("SELECT * FROM Partnerships ORDER BY id;")->fetch_all(MYSQLI_ASSOC);
foreach ($result['partnerships'] as &$partnership) {
    $partnership['id'] = intval($partnership['id']);
    $partnership['imageUrl'] = 'https://'.$_SERVER['SERVER_NAME'].'/assets-spade-club-heart-diamond/partnerships/'.$partnership['id'].'.png';
}

echo json_encode($result);

?>