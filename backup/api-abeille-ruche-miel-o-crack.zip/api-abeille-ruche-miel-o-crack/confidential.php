<?php

// db credentials
define('DB_HOST', 'localhost');
define('DB_USER', 'u587250627_wtd');
define('DB_PASS', 'C\'est qu01 une liste ?!');
define('DB_NAME', 'u587250627_wtd');

define('HCAPTCHA_SECRET', '0x80525437E4C3DfFC1282e614DA960ddb4A8249d5');
define('RECAPTCHA_SECRET', "6Lf9OIgeAAAAANDbxk6rYvyFt5Be3nkOi0P6J5yt")
// define('JWT_KEY', '!Bn0a0dMuBkOaOBMMBOaOkBuMd0a0nB!');

?>