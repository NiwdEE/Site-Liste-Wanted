<?php

include("../db.php");

$result = [];
$result['defis'] = connectToDB()->query("SELECT * FROM Defis ORDER BY finished DESC;")->fetch_all(MYSQLI_ASSOC);

$finishedDefis = [];
$postedDefis = [];
foreach ($result['defis'] as $d) {
    $defi = [];
    $defi['by'] = $d['author'];
    $defi['desc'] = $d['task'];
    $defi['postdate'] = $d['postdate'];
    if ($d['finished']=='1') {
        $defi['link'] = $d['evidenceLink'];
        $defi['madedate'] = $d['madedate'];
        array_push($finishedDefis, $defi);
    } else {
        array_push($postedDefis, $defi);
    }
}

$defis = [];
$defis['finished'] = $finishedDefis;
$defis['posted'] = $postedDefis;

echo json_encode($defis);

?>