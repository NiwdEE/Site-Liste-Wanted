<?php

$input = json_decode(file_get_contents('php://input'), true);

if($input != []) $_REQUEST=$input;

// print_r($input);

if (!isset($_REQUEST['author'], $_REQUEST['task'],$_REQUEST['token']) || $_REQUEST['author']=='' || $_REQUEST['task']=='' || empty($_REQUEST['token'])) {
    echo 'needdata';
    http_response_code(400);
    exit();
}

include("../db.php");


$response=file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".RECAPTCHA_SECRET."&response=".$_REQUEST['token']."&remoteip=".$_SERVER['REMOTE_ADDR']);

if(!$response->success){
    echo 'bad token';
    http_response_code(400);
    exit();
}

// if (!json_decode(file_get_contents('https://hcaptcha.com/siteverify?secret='.HCAPTCHA_SECRET.'&response='.$_REQUEST['token'].'&remoteip='.$_SERVER['REMOTE_ADDR']))->success) {
//     echo 'captchaerror';
//     http_response_code(400);
//     exit();
// }


$db = connectToDB();
$db->query("INSERT INTO `Defis` (`author`, `task`) VALUES ('".$db->real_escape_string($_REQUEST['author'])."', '".$db->real_escape_string($_REQUEST['task'])."');");

$tgBot = '5007791981:AAFWuLurTdcdRWQJVMnEcKTHNwM3qqmwgxA';
$data = [
    'chat_id' => '-1001226460221',
    'text' => 'Nouveau défi'."\n".'Posté par : '.$_REQUEST['author']."\n".$_REQUEST['task']
];
file_get_contents("https://api.telegram.org/bot$tgBot/sendMessage?".http_build_query($data));

?>