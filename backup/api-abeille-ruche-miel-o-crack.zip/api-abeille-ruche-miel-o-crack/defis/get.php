<?php

include("../db.php");

$result = [];
$result['defis'] = connectToDB()->query("SELECT * FROM Defis ORDER BY finished DESC;")->fetch_all(MYSQLI_ASSOC);
foreach ($result['defis'] as &$defi) {
    $defi['number'] = intval($defi['number']);
    $defi['finished'] = $defi['finished']=='1';
}
$result['canSubmit'] = true;

echo json_encode($result);

?>