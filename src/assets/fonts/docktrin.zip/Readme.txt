"Docktrin" Font
(c) 2014 by StereoType  [www.stereo-type.net]

The personal, non-commercial use of my font is free.
But Donations are accepted and highly appreciated!
The use of my fonts for commercial and profit purposes is prohibited,
unless a small donation is send to me.
Contact: clementnicolle@hotmail.com
These font files may not be modified and this readme file must be 
included with each font.
Redistribute? Sure, but send me an e-mail.
All trademarks are property of their respective owners.
